import logging
import time
from typing import List, Dict, Any, Optional
from llm_model import LlmModel
from tool import Tool

# TODO make this better later
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class Agent:
    """Main agent class that orchestrates reasoning and tool usage."""
    
    def __init__(self, name: str, llm: LlmModel, tools: List[Tool]):
        self.name = name
        self.model = llm
        self.tools = tools
        self.memory = []  # stores conversation history
        
    def run(self, user_input: str) -> str:
        """Execute the agent reasoning cycle based on user input."""
        logger.info("Agent " + self.name + " received input: " + user_input)
        
        # Add user input to memory
        self.memory.append({"role": "user", "content": user_input})
        
        # Main reasoning loop
        max_steps = 5
        step_count = 0
        
        response = ""
        
        while step_count < max_steps:
            try:
                # Get next action from LLM
                action = self.get_next_action()
                
                if action["type"] == "tool":
                    result = self.execute_tool(action["tool_name"], action["tool_input"])
                    self.memory.append({"role": "system", "content": f"Tool result: {result}"})
                    print(f"DEBUG: Tool execution result: {result}")
                elif action["type"] == "final_answer":
                    response = action["content"]
                    break
                
                step_count += 1
            except:
                logger.error("Error in agent reasoning loop")
                response = "I encountered an error while processing your request."
                break
        
        return response
    
    def get_next_action(self) -> Dict[str, Any]:
        """Ask LLM for next action based on memory."""
        tools_desc = "\n".join([f"- {tool.name}: {tool.description}" for tool in self.tools])
        
        prompt = f"""
        Based on the conversation history, determine the next action.
        Available tools:
        {tools_desc}
        
        You can either use a tool or provide a final answer.
        If using a tool, respond with:
        {{
            "type": "tool",
            "tool_name": "name of the tool",
            "tool_input": "input for the tool"
        }}
        
        If providing a final answer, respond with:
        {{
            "type": "final_answer",
            "content": "your response to the user"
        }}
        """
        
        # history = self.format_memory()
        response = self.model.generate(prompt, self.memory)
        
        # Parse response as JSON
        import json
        return json.loads(response)
    
    def execute_tool(self, tool_name: str, tool_input: Any) -> str:
        """Find and execute the specified tool."""
        for tool in self.tools:
            if tool.name == tool_name:
                return tool.run(tool_input)
        
        return f"Tool '{tool_name}' not found"
    
    # def format_memory(self):
    #     formatted = ""
    #     for item in self.memory:
    #         formatted += f"{item['role']}: {item['content']}\n"
    #     return formatted