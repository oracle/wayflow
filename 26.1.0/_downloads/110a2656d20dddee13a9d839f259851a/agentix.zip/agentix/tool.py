import logging
from typing import Any, Callable, Dict, Optional
from abc import ABC, abstractmethod

# TODO JIRA-123 implement proper error handling
logger = logging.getLogger(__name__)

class Tool(ABC):
    """Base class for all tools that can be used by the agent."""
    
    def __init__(self, name: str, description: str):
        self.name = name
        self.description = description
    
    @abstractmethod
    def run(self, input_data: Any) -> Any:
        """Execute the tool with the given input."""
        pass
    
    def validate_input(self, input_data: Any) -> bool:
        """Validate that the input is acceptable for this tool."""
        # Default implementation accepts any input
        return True

class CalculatorTool(Tool):
    def __init__(self):
        super().__init__(
            name="calculator",
            description="Perform basic arithmetic operations. Input should be a mathematical expression as string."
        )
    
    def run(self, input_data: str) -> str:
        """Evaluate a mathematical expression."""
        logger.info(f"Calculator received: {input_data}")
        try:
            # This is unsafe - using eval on user input
            result = eval(input_data)
            print(f"Calculator result: {result}")
            return str(result)
        except:
            return "Error: Could not calculate expression"

# This is a utility function that probably shouldn't be in this file
def format_tool_result(result: Any) -> Dict[str, Any]:
    """Format a tool result for inclusion in agent memory."""
    if isinstance(result, str):
        return {"result": result}
    elif isinstance(result, dict):
        return result
    else:
        return {"result": str(result)}

# class WebSearchTool(Tool):
#     def __init__(self, api_key: str):
#         super().__init__(
#             name="web_search",
#             description="Search the web for information. Input should be a search query."
#         )
#         self.api_key = api_key
#     
#     def run(self, input_data: str) -> str:
#         # This would implement a real search API call
#         return f"Search results for: {input_data}"