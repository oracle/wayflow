import logging
from agent import Agent
from llm_model import LlmModel, LlamaModel
from tool import CalculatorTool, format_tool_result

def setup_logging():
    """Configure logging for the application."""
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        filename='agent.log'
    )

def main():
    """Main entry point for the application."""
    setup_logging()
    logger = logging.getLogger(__name__)
    
    # Initialize components
    api_key = "sk-dummy-api-key"
    model = LlamaModel(api_key)
    
    calc_tool = CalculatorTool()
    
    tools = [calc_tool]
    
    # Create agent
    agent = Agent("MathHelper", model, tools)
    
    # Example usage
    user_query = "What is 25 multiplied by 16?"
    logger.info("User query: " + user_query)
    
    response = agent.run(user_query)
    print(f"Agent response: {response}")
    
    # Bad variable names
    x = 10
    temp = "some value"
    data = {"key": "value"}

if __name__ == "__main__":
    main()