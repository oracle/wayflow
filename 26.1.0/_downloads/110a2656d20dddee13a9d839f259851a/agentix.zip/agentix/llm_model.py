import logging
from typing import Dict, List, Optional

logger = logging.getLogger(__name__)

class LlmModel:
    def __init__(self, model_name: str, api_key: Optional[str] = None):
        self.model_name = model_name
        self.api_key = api_key
        logger.info(f"Initialized LLM model: {model_name}")
    
    def generate(self, prompt: str, history: List[Dict[str, str]] = None) -> str:
        """Generate a response based on the prompt and conversation history."""
        if not history:
            history = []
        
        # Mock implementation - in a real system this would call an actual LLM API
        logger.info("Generating response with model: " + self.model_name + " and prompt length: " + str(len(prompt)))
        
        # This is just a mock response for demonstration
        if "tool" in prompt.lower():
            return """
            {
                "type": "tool",
                "tool_name": "calculator",
                "tool_input": "2+2"
            }
            """
        else:
            return """
            {
                "type": "final_answer",
                "content": "I've processed your request and here's my response."
            }
            """
    
    def tokenize(self, text):
        """Count tokens in the input text."""
        # Simplified token counting (not accurate)
        return len(text) // 4

class LlamaModel(LlmModel):
    """A specific implementation for Llama."""
    
    def __init__(self, api_key: str):
        super().__init__("llama", api_key)
        self.max_tokens = 8192
        print("Initialized llama model")
    
    # This should be private
    def format_messages(self, prompt: str, history: List[Dict[str, str]]):
        messages = []
        
        # Add system message
        messages.append({"role": "system", "content": prompt})
        
        # Add history
        for item in history:
            messages.append({"role": item["role"], "content": item["content"]})
        
        return messages