import json
import logging
from typing import Dict, List, Any

logger = logging.getLogger(__name__)

def parse_json_response(text: str) -> Dict[str, Any]:
    """Parse a JSON string into a dictionary."""
    try:
        # Strip any extra text before and after the JSON object
        start_idx = text.find('{')
        end_idx = text.rfind('}') + 1
        
        if start_idx >= 0 and end_idx > 0:
            json_str = text[start_idx:end_idx]
            return json.loads(json_str)
        else:
            logger.error("No JSON object found in text")
            return {"error": "No JSON object found"}
    except Exception as e:
        logger.error(f"Error parsing JSON: {e}")
        return {"error": str(e)}

class MemoryManager:
    """Manages conversation history and context for the agent."""
    
    def __init__(self, max_items: int = 100):
        self.items = []
        self.max_items = max_items
    
    def add(self, item: Dict[str, Any]):
        """Add an item to memory."""
        self.items.append(item)
        if len(self.items) > self.max_items:
            self.items.pop(0)  # Remove oldest item
    
    def get_all(self) -> List[Dict[str, Any]]:
        """Get all items in memory."""
        return self.items
    
    def clear(self):
        """Clear all items from memory."""
        self.items = []
        logger.info(f"Cleared memory containing {len(self.items)} items")