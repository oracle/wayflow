<a id="top-execute-agentspec"></a>

# Execute Agent Spec Configuration with WayFlow![python-icon](_static/icons/python-icon.svg) Download Python Script

Python script/notebook for this guide.

[Execute Agent Spec with WayFlow how-to script](../end_to_end_code_examples/howto_execute_agentspec_with_wayflowcore.py)

#### Prerequisites
This guide assumes familiarity with [Agent Spec](https://github.com/oracle/agent-spec/) and exporting Agent Spec configurations.

This guide will show you how to:

1. Define the execution of tools in a tool registry.
2. Load an Agent Spec configuration with the WayFlow adapter.
3. Run the assistant and interact with it.

This guide shows you how to use a minimal Agent setup with a single tool for performing multiplications.
You can use the same code structure to load and run more complex assistants.

## 1. Install packages

To run the examples in this guide, make sure that `wayflowcore` is installed.

For more details, refer to the [WayFlow Agent Spec adapter API documentation](https://oracle.github.io/agent-spec/api/index.html).

## 2. Define the tool registry

Before loading the configuration, you need to define the tool registry.
This registry specifies how to execute each tool since the implementation of tools is not
included in the Agent Spec assistant configuration.

The example below shows how to register a single tool that performs multiplications.
Adapt this pattern to register all the tools your assistant requires.

This guide uses the simplest type of tool, `ServerTool`.
For more advanced tool types, refer to the [Agent Spec Language specification](https://oracle.github.io/agent-spec/agentspec/agentspec_language_spec_0_2.html).

```python
@tool(description_mode="only_docstring")
def multiplication_tool(a: int, b: int) -> int:
    """Tool that allows to compute multiplications."""
    return a * b

tool_registry = {
    "multiplication_tool": multiplication_tool,
}
```

## 3. Load the Agent Spec configuration

Now load the agent configuration.
The configuration starts by defining two components: `multiplication_tool` and `vllm_config`.
These are referenced in the agent definition later.

```python
AgentSpec_CONFIG = """
  $referenced_components:
    multiplication_tool:
      component_type: ServerTool
      description: Tool that allows to compute multiplications
      id: multiplication_tool
      inputs:
      - title: a
        type: integer
      - title: b
        type: integer
      name: multiplication_tool
      outputs:
      - title: product
        type: integer
    vllm_config:
      component_type: VllmConfig
      default_generation_parameters: null
      description: null
      id: vllm_config
      model_id: meta-llama/Meta-Llama-3.1-8B-Instruct
      name: llama-3.1-8b-instruct
      url: http://insert-your-model-url-here
  component_type: Agent
  llm_config:
    $component_ref: vllm_config
  name: Math homework assistant
  system_prompt: You are an assistant for helping with math homework.
  tools:
  - $component_ref: multiplication_tool
  agentspec_version: 25.4.1
"""
```

Loading the configuration to the WayFlow executor is simple as long as the `tool_registry` has been defined.

```python
from wayflowcore.agentspec import AgentSpecLoader

loader = AgentSpecLoader(tool_registry=tool_registry)
assistant = loader.load_yaml(AgentSpec_CONFIG)
```

## 4. Run the assistant

Start by creating a conversation.
Then prompt the user for some input.
The assistant will respond until you interrupt the process with Ctrl+C.
Messages of type `TOOL_REQUEST` and `TOOL_RESULT` are also displayed.
These messages help you understand how the assistant decides to act.

For more details, see the [API Reference](../api/conversation.md).

```python
from wayflowcore import MessageType
from wayflowcore import Agent

# %%
# Or with an execution loop
def run_agent_in_command_line(assistant: Agent):
    conversation = assistant.start_conversation()
    message_idx = 0
    while True:
        user_input = input("\nUSER >>> ")
        conversation.append_user_message(user_input)
        conversation.execute()
        messages = conversation.get_messages()
        for message in messages[message_idx + 1 :]:
            if message.message_type == MessageType.TOOL_REQUEST:
                print(f"\n{message.message_type.value} >>> {message.tool_requests}")
            else:
                print(f"\n{message.message_type.value} >>> {message.content}")
        message_idx = len(messages)

# run_agent_in_command_line(assistant)
# ^ uncomment and execute
```

You can also run a non-conversational flow.
In that case, the execution loop could be implemented as follows:

```python
def run_agent_non_conversational(assistant: Agent):
    conversation = assistant.start_conversation({ "some_input_name": "some_input_value"})
    conversation.execute()
    for output_name, output_value in conversation.state.input_output_key_values.items():
        print(f"{output_name} >>> \n{output_value}")

# run_agent_non_conversational(assistant)
# ^ uncomment and execute
```

### Agent Spec Exporting/Loading

You can export the assistant configuration to its Agent Spec configuration using the `AgentSpecExporter`.

```python
from wayflowcore.agentspec import AgentSpecExporter

config = AgentSpecExporter().to_json(assistant)
```

And load it back using the `AgentSpecLoader`.

```python
from wayflowcore.agentspec import AgentSpecLoader

tool_registry= {"multiplication_tool": multiplication_tool}
new_assistant = AgentSpecLoader(tool_registry=tool_registry).load_json(config)
```

### Next steps

In this guide, you learned how to:

1. Install the Agent Spec adapter for WayFlow.
2. Define tool execution using a tool registry.
3. Load an Agent Spec configuration with the WayFlow adapter.
4. Run the assistant and interact with it in a conversation loop.

You may now proceed to:

- [How to Connect to a MCP Server](howto_mcp.md)
- [How to Add User Confirmation to Tool Call Requests](howto_userconfirmation.md)

### Full code

Click on the card at the [top of this page](#top-execute-agentspec) to download the full code for this guide or copy the code below.

```python
# Copyright © 2025 Oracle and/or its affiliates.
#
# This software is under the Apache License 2.0
# %%[markdown]
# WayFlow Code Example - How to Execute Agent Spec with WayFlow
# -------------------------------------------------------------

# How to use:
# Create a new Python virtual environment and install the latest WayFlow version.
# ```bash
# python -m venv venv-wayflowcore
# source venv-wayflowcore/bin/activate
# pip install --upgrade pip
# pip install "wayflowcore==26.1.2" 
# ```

# You can now run the script
# 1. As a Python file:
# ```bash
# python howto_execute_agentspec_with_wayflowcore.py
# ```
# 2. As a Notebook (in VSCode):
# When viewing the file,
#  - press the keys Ctrl + Enter to run the selected cell
#  - or Shift + Enter to run the selected cell and move to the cell below# (LICENSE-APACHE or http://www.apache.org/licenses/LICENSE-2.0) or Universal Permissive License
# (UPL) 1.0 (LICENSE-UPL or https://oss.oracle.com/licenses/upl), at your option.


from wayflowcore.agentspec import AgentSpecLoader
from wayflowcore.tools import tool


# %%[markdown]
## AgentSpec Configuration

# %%
AgentSpec_CONFIG = """
  $referenced_components:
    multiplication_tool:
      component_type: ServerTool
      description: Tool that allows to compute multiplications
      id: multiplication_tool
      inputs:
      - title: a
        type: integer
      - title: b
        type: integer
      name: multiplication_tool
      outputs:
      - title: product
        type: integer
    vllm_config:
      component_type: VllmConfig
      default_generation_parameters: null
      description: null
      id: vllm_config
      model_id: meta-llama/Meta-Llama-3.1-8B-Instruct
      name: llama-3.1-8b-instruct
      url: http://insert-your-model-url-here
  component_type: Agent
  llm_config:
    $component_ref: vllm_config
  name: Math homework assistant
  system_prompt: You are an assistant for helping with math homework.
  tools:
  - $component_ref: multiplication_tool
  agentspec_version: 25.4.1
"""

# %%[markdown]
## Tool Registry Setup

# %%
@tool(description_mode="only_docstring")
def multiplication_tool(a: int, b: int) -> int:
    """Tool that allows to compute multiplications."""
    return a * b

tool_registry = {
    "multiplication_tool": multiplication_tool,
}

# %%[markdown]
## Load AgentSpec Configuration

# %%
from wayflowcore.agentspec import AgentSpecLoader

loader = AgentSpecLoader(tool_registry=tool_registry)
assistant = loader.load_yaml(AgentSpec_CONFIG)

# %%[markdown]
## Execution Loop Conversational

# %%
from wayflowcore import MessageType
from wayflowcore import Agent

# %%
# Or with an execution loop
def run_agent_in_command_line(assistant: Agent):
    conversation = assistant.start_conversation()
    message_idx = 0
    while True:
        user_input = input("\nUSER >>> ")
        conversation.append_user_message(user_input)
        conversation.execute()
        messages = conversation.get_messages()
        for message in messages[message_idx + 1 :]:
            if message.message_type == MessageType.TOOL_REQUEST:
                print(f"\n{message.message_type.value} >>> {message.tool_requests}")
            else:
                print(f"\n{message.message_type.value} >>> {message.content}")
        message_idx = len(messages)

# run_agent_in_command_line(assistant)
# ^ uncomment and execute

# %%[markdown]
## Execution Loop Non Conversational

# %%
def run_agent_non_conversational(assistant: Agent):
    conversation = assistant.start_conversation({ "some_input_name": "some_input_value"})
    conversation.execute()
    for output_name, output_value in conversation.state.input_output_key_values.items():
        print(f"{output_name} >>> \n{output_value}")

# run_agent_non_conversational(assistant)
# ^ uncomment and execute

# %%[markdown]
## Export Config to Agent Spec

# %%
from wayflowcore.agentspec import AgentSpecExporter

config = AgentSpecExporter().to_json(assistant)

# %%[markdown]
## Load Agent Spec Config

# %%
from wayflowcore.agentspec import AgentSpecLoader

tool_registry= {"multiplication_tool": multiplication_tool}
new_assistant = AgentSpecLoader(tool_registry=tool_registry).load_json(config)
```
